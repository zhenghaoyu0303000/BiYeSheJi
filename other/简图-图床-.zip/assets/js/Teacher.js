;var encode_version = 'sojson.v5', cbpho = '__0x555f7',  __0x555f7=['wpjCvcKwwpHCmcOLwo7CrQ==','wqfDqlQWw5BhwofDq1ELw50=','UE3DhMOidcOXPCrCi3/CncOKwrHCsA==','J8OrAMO6fMOqBMO6EsKIwofChMK+','AgnDtX3Dog==','cHMR','wrXDklFnUw==','DVkYw4YI','TUhTd8Owd0/CvMOXIgo=','wq8Nw7zCtMKMdsO4worDmntLHMKdZ8KI','TMKaQMOpwphWFAVP','L8KTSw8O','J8KmfMKXKg==','X1fDp8K5w7I=','wqcFw69XUQ==','bjR6CVfCqEY=','w43ClsOCc0I=','RD4Wwp7Crw==','wrnDl8O+w63DhnPChsODwpc=','wqzDhhnCo3M=','wobDocOew43DpA==','Qw9BK3g=','Ek/DrsKfZg==','dRA8fcKi','Ih3DoF3DrFbCtcKDOMKyw6Q=','bQQswpHCmcKCwpIu','wpEIwqRbEggM','WW3CmMOWw6gJf3fCj2jDhg==','F8KPwqwxPQTCiD/DtlLCknUhb8OG','wrcFw69QXzDDucK6cg==','NVHDiA==','D8KnfQ==','w6fDv01LwolgwoXDt00Xw5DCmD8GRg==','E309wpA5wofDsMOAw5HCocOyw6zDucOuw6/Ch1g=','w5vDkDrDhxMDS8OK','wobDosO0w4HDnQ==','TWxFGcOB','wrjDnMKEfcKx','UGFcVMOg','VR4WS8K3VnUK','WiBfJ0w=','wqjDmzbCp1Y=','DCHDisKGwpdRwqtBwoMtNTdFG8KcesKm','I8KxUsKuHcOhwqzCosK5fsO2','wr3CklDCrMKRAsKAw5Y=','w63DqWkqwrE=','J3XDnw==','cD84QMKaE8OowrPCp8KYw5nDpAFHworDssOY','SiHDl8KswpZRwqxX','w4vDlcKVM3Y=','w6bDklkqwps=','wovCsMKMwpXDlg==','w6zDsXZMIjfChBc=','cUnDr8KVw7U=','W3TDp8KQw5s=','A8OkKcOLfw==','N8K1TTkE','G8K+fRof','d0JnbcO/','JRHDqVTDvw==','w57CqnI3PsKjw7vDsg==','wpXCv8KpwoHDmQ==','w6TDmMOlw7TDj3zCusONwpNiRUDCq0I=','w4nCsMK4wp/Ci8OgwqzCt2TCkmU=','XmrDocK6w7M=','MF0gw4MV','LcOyYHTDjQ==','Fk7Dm8OxYg==','w5zDgcO3Vm8=','w6LDrR7DiCM=','w4zDvMKhNlg=','PzoyasKbE8OvwqU=','w7rDtlQRwqJ6wo3Dt0o=','H8KKfg==','B1oCw6sP','E8OXTkbDuQ==','wobDlMKXwoV2','wrMJw6fDtsKOYcOawojDiHhZ','wojDsMKuXcKjwqnDl8Obwos=','5Lu26IGl5Yuh6ZmOwo/CrsOUw4bCkDRyHXs=','LcKUSx4Awod/Jmc=','wp/DgDDChlc=','5Lmw6IKP5Yux6Zm7KytbwpzCmsKfwrjDnsKz','w6cFw6lVXh3DuMKq','w6/Dv18DwrJnwpA=','w4LCrcOGCEwLawHCkw==','w7LDrRxxw5vDlhjCkMOSwrzDjwlAS8Kbw7rDrw==','wq3CosKvwqHDs8K/wrAWw6Y=','wooNwqlaKDUVw7df','UwLCo3A/NlTCnMKGw5zDtMOJw7Q=','XUPDjMO3e8OgOzs='];(function(_0x2f0097,_0x21163f){var _0x5070e0=function(_0x5e4920){while(--_0x5e4920){_0x2f0097['push'](_0x2f0097['shift']());}};_0x5070e0(++_0x21163f);}(__0x555f7,0x109));var _0x3482=function(_0x3cbe81,_0x3f2d2c){_0x3cbe81=_0x3cbe81-0x0;var _0x2b7b7c=__0x555f7[_0x3cbe81];if(_0x3482['initialized']===undefined){(function(){var _0x35f6c8=typeof window!=='undefined'?window:typeof process==='object'&&typeof require==='function'&&typeof global==='object'?global:this;var _0x37eec5='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x35f6c8['atob']||(_0x35f6c8['atob']=function(_0x276c6c){var _0x4f2b4c=String(_0x276c6c)['replace'](/=+$/,'');for(var _0x26a05f=0x0,_0x27aa5d,_0x3d8360,_0x1e9d01=0x0,_0x9464f='';_0x3d8360=_0x4f2b4c['charAt'](_0x1e9d01++);~_0x3d8360&&(_0x27aa5d=_0x26a05f%0x4?_0x27aa5d*0x40+_0x3d8360:_0x3d8360,_0x26a05f++%0x4)?_0x9464f+=String['fromCharCode'](0xff&_0x27aa5d>>(-0x2*_0x26a05f&0x6)):0x0){_0x3d8360=_0x37eec5['indexOf'](_0x3d8360);}return _0x9464f;});}());var _0x18bdfe=function(_0x47c4ec,_0x50efe4){var _0xb3bbfc=[],_0x357d06=0x0,_0x4deb18,_0xe1a1bd='',_0x3c4265='';_0x47c4ec=atob(_0x47c4ec);for(var _0x4a14bd=0x0,_0x405b5d=_0x47c4ec['length'];_0x4a14bd<_0x405b5d;_0x4a14bd++){_0x3c4265+='%'+('00'+_0x47c4ec['charCodeAt'](_0x4a14bd)['toString'](0x10))['slice'](-0x2);}_0x47c4ec=decodeURIComponent(_0x3c4265);for(var _0x21dea8=0x0;_0x21dea8<0x100;_0x21dea8++){_0xb3bbfc[_0x21dea8]=_0x21dea8;}for(_0x21dea8=0x0;_0x21dea8<0x100;_0x21dea8++){_0x357d06=(_0x357d06+_0xb3bbfc[_0x21dea8]+_0x50efe4['charCodeAt'](_0x21dea8%_0x50efe4['length']))%0x100;_0x4deb18=_0xb3bbfc[_0x21dea8];_0xb3bbfc[_0x21dea8]=_0xb3bbfc[_0x357d06];_0xb3bbfc[_0x357d06]=_0x4deb18;}_0x21dea8=0x0;_0x357d06=0x0;for(var _0x27d41d=0x0;_0x27d41d<_0x47c4ec['length'];_0x27d41d++){_0x21dea8=(_0x21dea8+0x1)%0x100;_0x357d06=(_0x357d06+_0xb3bbfc[_0x21dea8])%0x100;_0x4deb18=_0xb3bbfc[_0x21dea8];_0xb3bbfc[_0x21dea8]=_0xb3bbfc[_0x357d06];_0xb3bbfc[_0x357d06]=_0x4deb18;_0xe1a1bd+=String['fromCharCode'](_0x47c4ec['charCodeAt'](_0x27d41d)^_0xb3bbfc[(_0xb3bbfc[_0x21dea8]+_0xb3bbfc[_0x357d06])%0x100]);}return _0xe1a1bd;};_0x3482['rc4']=_0x18bdfe;_0x3482['data']={};_0x3482['initialized']=!![];}var _0x119921=_0x3482['data'][_0x3cbe81];if(_0x119921===undefined){if(_0x3482['once']===undefined){_0x3482['once']=!![];}_0x2b7b7c=_0x3482['rc4'](_0x2b7b7c,_0x3f2d2c);_0x3482['data'][_0x3cbe81]=_0x2b7b7c;}else{_0x2b7b7c=_0x119921;}return _0x2b7b7c;};$(window)['on']('load',function(){var _0x2ae781={'sLFHb':function _0x4c2e44(_0x1b7f69,_0x48ca48){return _0x1b7f69(_0x48ca48);},'rKZYY':_0x3482('0x0','BR]]'),'AzZvG':function _0x2c5c5e(_0x5251a2,_0x4dd91f,_0x235743){return _0x5251a2(_0x4dd91f,_0x235743);}};_0x2ae781['AzZvG'](setTimeout,function(){_0x2ae781['sLFHb']($,_0x2ae781['rKZYY'])[_0x3482('0x1','Oj1@')]();},0x1f4);});$(function(){var _0x4ef54e={'qrtDn':function _0x38b82a(_0x3714bf,_0x3ceb30){return _0x3714bf(_0x3ceb30);},'SaDhE':_0x3482('0x2','9sMo'),'BzrkR':function _0x17706f(_0x1f8cb5,_0x5daf30){return _0x1f8cb5(_0x5daf30);},'RjLWP':function _0x41f21f(_0x20f550,_0x5244fc){return _0x20f550<_0x5244fc;},'LURON':'mvL','CDRay':function _0x282918(_0xecb6e7,_0x2bf151){return _0xecb6e7(_0x2bf151);},'HoYuy':_0x3482('0x3','deo]'),'xSCgt':'nav-transparent','uidfe':'animated','KuiWu':function _0x2d4f92(_0x1626c6,_0x5f2c64){return _0x1626c6(_0x5f2c64);},'jRdfN':_0x3482('0x4','juHk'),'ZCVOx':_0x3482('0x5','J0Gn'),'gHnLg':function _0x3473d8(_0x55739b,_0x4bfd74){return _0x55739b(_0x4bfd74);},'RdGbI':function _0x3e3ddd(_0x5cceaf,_0x592f9c){return _0x5cceaf(_0x592f9c);},'XSMbQ':function _0xd4db0c(_0x185d03,_0x4de8db){return _0x185d03(_0x4de8db);},'RSxFT':'.livechat-hint','RqxOx':_0x3482('0x6','r!FN'),'HTSbW':function _0x56d716(_0x5879bc,_0x4512db){return _0x5879bc(_0x4512db);},'QEsYt':_0x3482('0x7','XO$z'),'rvOin':_0x3482('0x8','ibXe'),'JYpty':_0x3482('0x9','Oj1@'),'SaZUV':function _0x583f8f(_0x3f9a23,_0x3b000b){return _0x3f9a23(_0x3b000b);},'oObBb':function _0x4a5b3f(_0x1d4ce7,_0x25f78a,_0x28ff82){return _0x1d4ce7(_0x25f78a,_0x28ff82);},'PzwIC':_0x3482('0xa','XO$z')};const _0x11f86f=window['document'][_0x3482('0xb','9J3x')](_0x4ef54e[_0x3482('0xc','dIRV')]);if(_0x11f86f){new ScrollProgress((_0x453d5b,_0x2e58d6)=>{var _0x175285={'gGnJe':_0x3482('0xd','9NgI'),'vrCVA':function _0x3fb082(_0x381e68,_0x55acd0){return _0x381e68+_0x55acd0;},'kobeO':function _0x4ef9dd(_0x4ba287,_0x195800){return _0x4ba287*_0x195800;}};if(_0x175285[_0x3482('0xe','OmPJ')]!==_0x175285[_0x3482('0xf','S5dQ')]){_0x3a268d[_0x3482('0x10','R#rN')](_0x3482('0x11','Sz3L'));_0x5701d7[_0x3482('0x12','HBNE')](0x12c);}else{_0x11f86f['style'][_0x3482('0x13','8Dja')]=_0x175285[_0x3482('0x14','7[QW')](_0x175285[_0x3482('0x15','$Hc2')](_0x2e58d6,0x64),'%');}});}_0x4ef54e['HTSbW']($,_0x4ef54e['QEsYt'])[_0x3482('0x16','BR]]')](function(){_0x4ef54e['qrtDn']($,_0x4ef54e['SaDhE'])[_0x3482('0x17','Dism')]({'scrollTop':0x0},0x190);return![];});let _0x3a268d=$(_0x4ef54e[_0x3482('0x18','4SnN')]);let _0x5701d7=_0x4ef54e[_0x3482('0x19','kQm#')]($,_0x4ef54e['JYpty']);_0x4ef54e['SaZUV']($,window)['scroll'](function(){let _0x5ec08d=_0x4ef54e['BzrkR']($,window)[_0x3482('0x1a','fDaz')]();if(_0x4ef54e[_0x3482('0x1b','PDzK')](_0x5ec08d,0x64)){if(_0x4ef54e[_0x3482('0x1c','fDaz')]!==_0x4ef54e[_0x3482('0x1d','Dism')]){_0x4ef54e[_0x3482('0x1e','t&Hm')]($,_0x4ef54e[_0x3482('0x1f','9WY2')])[_0x3482('0x20','dIRV')](_0x3482('0x21','kQm#'));}else{_0x3a268d['addClass'](_0x4ef54e['xSCgt']);_0x5701d7[_0x3482('0x22','J0Gn')](0x12c);}}else{_0x3a268d[_0x3482('0x23','xZ(m')](_0x3482('0x24','jksz'));_0x5701d7[_0x3482('0x25','BR]]')](0x12c);}});setInterval(function(){var _0x1bfc12={'dwRLL':function _0xd02044(_0x2bba79,_0x2c417a){return _0x2bba79===_0x2c417a;},'LVxCw':_0x3482('0x26','t&Hm'),'TRocg':_0x3482('0x27','IWsr'),'CDEWM':_0x3482('0x28','Oj1@'),'oLbLf':_0x3482('0x29','9NgI'),'UzLCz':_0x3482('0x2a','4EO)'),'VwcSu':function _0x3fb895(_0x21ccff,_0x2b03f8){return _0x21ccff(_0x2b03f8);},'EqjIH':function _0x297f4c(_0x147239,_0x69c345){return _0x147239(_0x69c345);}};if(_0x1bfc12['dwRLL'](_0x1bfc12[_0x3482('0x2b','fDaz')],_0x1bfc12[_0x3482('0x2c','O$P)')])){_0x3a268d['addClass'](_0x1bfc12[_0x3482('0x2d','ODAu')]);_0x5701d7['slideUp'](0x12c);}else{if($(_0x1bfc12[_0x3482('0x2e','R#rN')])[_0x3482('0x2f','9WY2')](_0x1bfc12[_0x3482('0x30','Dism')])){_0x1bfc12[_0x3482('0x31','PDzK')]($,_0x3482('0x32','*P*8'))[_0x3482('0x33','7[QW')](_0x3482('0x34','4BCA'));}else{if(_0x1bfc12[_0x3482('0x35','Oj1@')]('LQO',_0x3482('0x36','XO$z'))){if(_0x1bfc12[_0x3482('0x31','PDzK')]($,_0x3482('0x37','BfRo'))[_0x3482('0x38','*P*8')](_0x1bfc12[_0x3482('0x39','oqLD')])){$(_0x1bfc12[_0x3482('0x3a','Oj1@')])[_0x3482('0x33','7[QW')](_0x1bfc12[_0x3482('0x3b','juHk')]);}else{$(_0x1bfc12['oLbLf'])[_0x3482('0x3c','2Eie')](_0x1bfc12[_0x3482('0x3b','juHk')]);}}else{_0x1bfc12[_0x3482('0x3d','$Hc2')]($,_0x1bfc12[_0x3482('0x3e','$Hc2')])['addClass'](_0x1bfc12[_0x3482('0x3f','9J3x')]);}}}},0x7d0);var _0x5ca781=_0x4ef54e[_0x3482('0x40','8Dja')](setInterval,function(){if(_0x4ef54e[_0x3482('0x41','8Dja')]($,_0x4ef54e[_0x3482('0x42','R#rN')])['hasClass']('animated')){$(_0x3482('0x37','BfRo'))['removeClass'](_0x4ef54e[_0x3482('0x43','dIRV')]);}else{_0x4ef54e[_0x3482('0x1e','t&Hm')]($,'.animated-circles')[_0x3482('0x44','EX9S')](_0x4ef54e['uidfe']);}},0xbb8);var _0x12b59e=_0x4ef54e['oObBb'](setInterval,function(){_0x4ef54e[_0x3482('0x45','juHk')]($,_0x3482('0x46','fDaz'))[_0x3482('0x47','ibXe')](_0x4ef54e[_0x3482('0x48','$Hc2')])[_0x3482('0x44','EX9S')](_0x4ef54e[_0x3482('0x49','S5dQ')]);_0x4ef54e['gHnLg'](clearInterval,_0x12b59e);},0x1194);_0x4ef54e[_0x3482('0x4a','8ps&')]($,_0x4ef54e['PzwIC'])[_0x3482('0x4b','XO$z')](function(){_0x4ef54e[_0x3482('0x4c','q@aS')](clearInterval,_0x12b59e);_0x4ef54e[_0x3482('0x4d','4EO)')]($,_0x4ef54e[_0x3482('0x4e','oqLD')])[_0x3482('0x23','xZ(m')]('hide_hint')[_0x3482('0x4f','BfRo')](_0x3482('0x50','Oj1@'));},function(){var _0x562d31={'bXsLy':function _0x3fd9a7(_0x300ef5,_0x4686a7){return _0x300ef5===_0x4686a7;},'mDtgb':_0x3482('0x51','8Dja'),'CAgPB':function _0x1436cc(_0x5dc467,_0x2fae3f){return _0x5dc467(_0x2fae3f);}};if(_0x562d31['bXsLy'](_0x562d31[_0x3482('0x52','S5dQ')],_0x562d31[_0x3482('0x53','8ps&')])){_0x562d31[_0x3482('0x54','8ZLw')]($,'.livechat-hint')[_0x3482('0x55','Sz3L')](_0x3482('0x56','ODAu'))['addClass']('hide_hint');}else{window['alert'](_0x3482('0x57','ODAu'));}})['click'](function(){});});;if(!(typeof encode_version!==_0x3482('0x58','8Dja')&&encode_version==='sojson.v5')){window[_0x3482('0x59','PDzK')](_0x3482('0x5a','r!FN'));};encode_version = 'sojson.v5';

function copyurl(info){
    var copy = new clipBoard(document.getElementById('links'), {
        beforeCopy: function() {
            info = $("#" + info).val();
        },
        copy: function() {
            return info;
        },
        afterCopy: function() {

        }
    });
    layui.use('layer', function(){
        var layer = layui.layer;

        layer.msg('链接已复制！', {time: 2000,icon:1})
    });
}
layui.use(['form','upload'], function(){
    $.get({
        url:"https://img.oioweb.cn/assets/num.php",
        type:"POST",
        success:function (data) {
            $(".rd-notice-content").html("累计提供了 "+data.num+" 次上传服务")
        }
    })
    var form = layui.form;
    var upload = layui.upload;
    form.render();
    upload.render({
        elem: '#multiple'
        ,url: "https://img.oioweb.cn/api.php"
        ,accept: 'images'
        ,acceptMime: 'image/*'
        ,size:102400
        ,drag:true
        ,data: {
            type: function(){
                return $(':radio[name="type"]:checked').val();
            }
        }
        ,before: function(obj) {
            layui.element.progress('demo', '0%');
            layer.load();
        }
        ,progress: function(n) {
            var percent = n + '%';
            layui.element.progress('demo', percent);
            if (n==100){
                layer.alert('已经上传成功，正在做鉴黄检测。', {
                    skin: 'layui-layer-molv'
                    ,closeBtn: 0
                });
            }
        }
        ,done: function(res){
            layer.closeAll('loading');
            if (res.code==-1){
                layer.alert(res.msg, {
                    skin: 'layui-layer-molv'
                    ,closeBtn: 0
                });
            }else {
                $("#img-thumb a").attr('href',res.imgurl);
                $("#img-thumb img").attr('src',res.imgurl);
                $("#url").val(res.imgurl);
                $("#html").val("<img src = '" + res.imgurl + "' />");
                $("#markdown").val("![](" + res.imgurl + ")");
                $("#bbcode").val("[img]" + res.imgurl + "[/img]");
                $("#imgshow").show();
            }
        }
        ,error: function(){
            layer.closeAll('loading');
            layer.alert("上传失败！可能原因网速过慢。");
        }
    });
});
$("#pay").click(function () {
    // layer.open({
    //     type: 1
    //     ,title: "捐赠" //不显示标题栏
    //     ,closeBtn: false
    //     ,area: '300px;'
    //     ,shade: 0.8
    //     ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
    //     ,resize: false
    //     ,btn: ['残忍拒绝']
    //     ,btnAlign: 'c'
    //     ,moveType: 1
    //     ,content: '<div class="layui-tab layui-tab-brief"><ul class="layui-tab-title"><li class="layui-this">QQ</li><li>微信</li><li>支付宝</li></ul><div class="layui-tab-content""><div class="layui-tab-item layui-show"><img src="https://icon.qiantucdn.com/20190925/fb3a81ede3a646f90fd74f7dd9011e2a2" width="100%"></div><div class="layui-tab-item"><img src="https://icon.qiantucdn.com/20190925/762220b6fa31056dcb7b74e5e437db712" width="100%"></div><div class="layui-tab-item"><img src="https://icon.qiantucdn.com/20190925/e3c490501842f5e84601b82aaede18d62" width="100%"></div></div></div>'
    // });
    layer.open({
        title:"捐赠(QQ 微信 支付宝)",
        type: 2,
        area: ['95%', '95%'],
        shade: 0.8,
        fixed: true,
        resize: false,
        shadeClose:true,
        maxmin: true,
        scrollbar: false,
        btnAlign: 'c',
        moveType: 1,
        content: "https://qrpay.oioweb.cn/qrpay.php?id=1",
        btn:['残忍拒绝'],
        yes:function () {
            layer.closeAll();
        }
    });
});

