<?php
	$handle = opendir('./cache');
 
	while (false !==$file = readdir($handle)){
		
		if ($file !='.' && $file != '..'){
			$file_fullpath = './cache'."/".$file;
			echo iconv('GBK', 'utf-8', $file_fullpath);
			echo "<br />";
			if (!is_dir($file_fullpath)){
				unlink($file_fullpath);
			}else{
				rmdir($file_fullpath);
			}
		}	
	}
?>